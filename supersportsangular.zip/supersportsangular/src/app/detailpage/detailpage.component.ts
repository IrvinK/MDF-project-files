import { Component } from '@angular/core';

@Component({
  selector: 'detailpage',
  templateUrl: `./app/detailpage/detailpage.component.html`,
})

export class DetailpageComponent{
  
}
