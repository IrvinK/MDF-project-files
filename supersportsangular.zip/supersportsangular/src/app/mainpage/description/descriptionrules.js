"use strict";
//# sourceMappingURL=descriptionrules.js.map