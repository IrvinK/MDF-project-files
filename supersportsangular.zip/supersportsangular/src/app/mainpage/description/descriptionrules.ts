
export interface IShoes {
    id: number,
    image: string,
    title: string,
    subtitle: string,
    description: string,
    price: number
}