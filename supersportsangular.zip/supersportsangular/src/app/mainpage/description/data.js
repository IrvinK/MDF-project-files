"use strict";
exports.SHOEDATA = [{
        id: 1,
        image: "app/mainpage/images/blackshoe.png",
        title: 'BLACKSHOE XYZ',
        subtitle: 'SUBTITLE FOR SHOE',
        description: 'Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsumLorem ipsum ipsum Lorem ipsum Lorem',
        price: 50
    },
    {
        id: 2,
        image: "app/mainpage/images/blackshoe.png",
        title: 'BLACKSHOE XYZ',
        subtitle: 'SUBTITLE FOR SHOE',
        description: 'Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsumLorem ipsum ipsum Lorem ipsum Lorem',
        price: 50
    },
    {
        id: 3,
        image: "app/mainpage/images/blackshoe.png",
        title: 'BLACKSHOE XYZ',
        subtitle: 'SUBTITLE FOR SHOE',
        description: 'Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsumLorem ipsum ipsum Lorem ipsum Lorem',
        price: 50
    },
    {
        id: 4,
        image: "app/mainpage/images/blackshoe.png",
        title: 'BLACKSHOE XYZ',
        subtitle: 'SUBTITLE FOR SHOE',
        description: 'Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsumLorem ipsum ipsum Lorem ipsum Lorem',
        price: 50
    },
    {
        id: 5,
        image: "app/mainpage/images/blackshoe.png",
        title: 'BLACKSHOE XYZ',
        subtitle: 'SUBTITLE FOR SHOE',
        description: ' Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsumLorem ipsum ipsum Lorem ipsum Lorem',
        price: 50
    },
    {
        id: 6,
        image: "app/mainpage/images/blackshoe.png",
        title: 'BLACKSHOE XYZ',
        subtitle: 'SUBTITLE FOR SHOE',
        description: 'Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsumLorem ipsum ipsum Lorem ipsum Lorem',
        price: 50
    },
    {
        id: 7,
        image: "app/mainpage/images/blackshoe.png",
        title: 'BLACKSHOE XYZ',
        subtitle: 'SUBTITLE FOR SHOE',
        description: 'Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsumLorem ipsum ipsum Lorem ipsum Lorem',
        price: 50
    },
    {
        id: 8,
        image: "app/mainpage/images/blackshoe.png",
        title: 'BLACKSHOE XYZ',
        subtitle: 'SUBTITLE FOR SHOE',
        description: 'Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsum Lorem ipsum ipsumLorem ipsum ipsum Lorem ipsum Lorem',
        price: 50
    }];
//# sourceMappingURL=data.js.map