import { Component } from '@angular/core';

@Component({
  selector: 'mainpage',
  templateUrl: `./app/mainpage/mainpage.component.html`,
}) 
 


export class MainComponent{

}
