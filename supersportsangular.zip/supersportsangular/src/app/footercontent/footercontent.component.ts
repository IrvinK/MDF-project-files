import { Component } from '@angular/core';

@Component({
  selector: 'footercontent',
  templateUrl: `./app/footercontent/footercontent.component.html`,
})


export class FooterContent{

}