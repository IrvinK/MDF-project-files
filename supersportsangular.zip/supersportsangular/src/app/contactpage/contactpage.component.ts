import { Component } from '@angular/core';

@Component({
  selector: 'contactpage',
  templateUrl: `./app/contactpage/contactpage.component.html`,
 })


export class ContactpageComponent{
  
}
