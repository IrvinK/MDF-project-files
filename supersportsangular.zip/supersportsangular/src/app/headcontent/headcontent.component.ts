import { Component } from '@angular/core';

@Component({
  selector: 'headcontent',
  templateUrl: `./app/headcontent/headcontent.component.html`,
 })


export class HeadContent{

}